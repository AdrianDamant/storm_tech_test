﻿using CXmlInvoiceGenerator.helpers;
using CXmlInvoiceGenerator.Infrastructure.Entities;
using DatabaseAccess;
using System.Configuration;
using System.Data;
using System.Xml;
using CXmlInvoiceGenerator.Infrastructure;

namespace CXmlInvoiceGenerator
{
    internal class Program
    {
        //Fetch the File Path to export the cXML .xml files to//
        //DEFAULT VALUE: C:\Users\Public\Documents\CXML Invoices\
        private static string InvoiceFilePath = ConfigurationManager.AppSettings["Invoice_File_Path"].ToString();
        
        //Fetch demo variables - holding domains, identities, secrets
        private static string FromDomain = ConfigurationManager.AppSettings["From_Domain"].ToString();
        private static string FromIdentity = ConfigurationManager.AppSettings["From_Identity"].ToString();
        private static string ToDomain = ConfigurationManager.AppSettings["To_Domain"].ToString();
        private static string ToIdentity = ConfigurationManager.AppSettings["To_Identity"].ToString();
        private static string SenderDomain = ConfigurationManager.AppSettings["Sender_Domain"].ToString();
        private static string SenderIdentity = ConfigurationManager.AppSettings["Sender_Identity"].ToString();
        private static string SenderShareSecret = ConfigurationManager.AppSettings["Sender_ShareSecret"].ToString();

        private static CreateXMLHelper createXMLHelper;

        static void Main(string[] args)
        {
            Console.WriteLine("New invoice generation run starting at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            Console.WriteLine("-------------");
            Console.WriteLine("-------------");
            Console.WriteLine("Invoice File Export Path Set to: " + InvoiceFilePath);
            Console.WriteLine("-------------");
            Console.WriteLine("-------------");

            createXMLHelper = new CreateXMLHelper(InvoiceFilePath,
                FromDomain,
                FromIdentity,
                ToDomain,
                ToIdentity,
                SenderDomain,
                SenderIdentity,
                SenderShareSecret);

            GenerateCXMLForNewInvoices();

            Console.WriteLine("-------------");
            Console.WriteLine("-------------");
            Console.WriteLine("New invoice generation run finishing at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

            System.Diagnostics.Process.Start(Environment.GetEnvironmentVariable("WINDIR") +
                @"\explorer.exe", InvoiceFilePath);
        }


        private static void GenerateCXMLForNewInvoices()
        {
            try
            {
                //Fetch Invoices From DataSource//
                Invoices invoiceDB = new();
                DataTable newInvoices = invoiceDB.GetNewInvoices();
                //Parse them into List<Invoice>
                List<Invoice> invoices = EntityParseManager.ParseInvoices(newInvoices);
                for (int a = 0; a < invoices.Count; a++)
                {
                    //For Loop to step through each invoice for processing into cXML File
                    createXMLHelper.Create_cXMLFile(invoices[a],
                        EntityParseManager.ParseInvoiceLineItems(invoiceDB.GetItemsOnInvoice(invoices[a].Id)),
                        EntityParseManager.ParseAddress(invoiceDB.GetDeliveryAddressForSalesOrder(invoices[a].SalesOrderId)),
                        EntityParseManager.ParseAddress(invoiceDB.GetBillingAddressForInvoice(invoices[a].Id)));
                }
            }
            catch (Exception ee)
            {
                Console.WriteLine("Exception: cXML Export Failed: " + ee.ToString());
            }
        }
    }
}