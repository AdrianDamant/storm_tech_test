﻿using CXmlInvoiceGenerator.Infrastructure.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CXmlInvoiceGenerator.Infrastructure
{
    internal class CreateXMLHelper
    {
        private string InvoiceFilePath;
        private string FromDomain;
        private string FromIdentity;
        private string ToDomain;
        private string ToIdentity;
        private string SenderDomain;
        private string SenderIdentity;
        private string SenderShareSecret;
        public CreateXMLHelper( string InvoiceFilePath,
         string FromDomain,
         string FromIdentity,
         string ToDomain,
         string ToIdentity,
         string SenderDomain,
         string SenderIdentity,
         string SenderShareSecret)
        {
            this.InvoiceFilePath = InvoiceFilePath;
            this.FromDomain = FromDomain;
            this.FromIdentity = FromIdentity;
            this.ToDomain = ToDomain; 
            this.ToIdentity = ToIdentity;
            this.SenderDomain = SenderDomain;
            this.SenderIdentity = SenderIdentity;
            this.SenderShareSecret = SenderShareSecret;
        }
        public void Create_cXMLFile(Invoice invoiceCurrent, List<InvoiceLineItem> lstLineItems, Address addreddDelivery, Address addressBilling)
        {
            //Create unique file name based on invoice number, with previx INV, using the variable strInvoiceFilePath stored in App Config Settings//
            var strFileName = InvoiceFilePath + @"\INV" + invoiceCurrent.Id + ".xml";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;

            //Create XML Using XmlxmlWriter - Increased speed over Serializing an entity to handle volume requests//
            using (System.IO.FileStream stream = System.IO.File.Create(strFileName))
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(stream, settings))
                {
                    xmlWriter.WriteDocType("cXML", null, "http://xml.cxml.org/schemas/cXML/1.2/InvoiceDetail.dtd", null);
                    xmlWriter.WriteStartElement("cXML");
                    xmlWriter.WriteAttributeString("version", "1.0");
                    xmlWriter.WriteAttributeString("payloadID", "xxx.xxxx@example.coupahost.com");
                    xmlWriter.WriteAttributeString("timestamp", DateTime.Now.ToString());

                    //Code in cXML Header//
                    xmlWriter.WriteStartElement("Header");
                    xmlWriter.WriteStartElement("From");
                    xmlWriter.WriteStartElement("Credential");
                    xmlWriter.WriteAttributeString("domain", "DUNS");
                    xmlWriter.WriteElementString("Identity", "xxxxxxxx");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("To");
                    xmlWriter.WriteStartElement("Credential");
                    xmlWriter.WriteAttributeString("domain", "NetworkID");
                    xmlWriter.WriteElementString("Identity", "yyyyyyyy");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("Sender");
                    xmlWriter.WriteStartElement("Credential");
                    xmlWriter.WriteAttributeString("domain", "NetworkID");
                    xmlWriter.WriteElementString("Identity", "xxxxxxxxx");
                    xmlWriter.WriteElementString("SharedSecret", "xxxxxxxxx");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    //END of Header

                    //Start Request
                    xmlWriter.WriteStartElement("Request");
                    xmlWriter.WriteAttributeString("deploymentMode", "production");

                    xmlWriter.WriteStartElement("InvoiceDetailRequest");

                    xmlWriter.WriteStartElement("InvoiceDetailRequestHeader");
                    xmlWriter.WriteAttributeString("invoiceID", invoiceCurrent.Id.ToString());
                    xmlWriter.WriteAttributeString("purpose", "standard");
                    xmlWriter.WriteAttributeString("operation", "new");
                    xmlWriter.WriteAttributeString("invoiceDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    xmlWriter.WriteStartElement("InvoiceDetailHeaderIndicator"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("InvoiceDetailLineIndicator"); xmlWriter.WriteAttributeString("isTaxInLine", "no"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("InvoicePartner");
                    xmlWriter.WriteStartElement("Contact");
                    xmlWriter.WriteAttributeString("role", "soldTo");
                    xmlWriter.WriteStartElement("Name"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US");
                    xmlWriter.WriteString(addressBilling.ContactName); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("PostalAddress");
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addressBilling.AddrLine1); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addressBilling.AddrLine2); xmlWriter.WriteEndElement();
                    //Can only have 3 Street Parameters according to SAP guidelines//
                    //https://help.sap.com/docs/ariba/sap-ariba-applications-2005-q2-2020-release-guide/invoice-to-cxml-data-mapping
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addressBilling.AddrLine3); xmlWriter.WriteEndElement();
                    //Assumed Address 4 & 5 hold City and State data
                    xmlWriter.WriteStartElement("City"); xmlWriter.WriteString(addressBilling.AddrLine4); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("State"); xmlWriter.WriteString(addressBilling.AddrLine5); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("PostalCode"); xmlWriter.WriteString(addressBilling.AddrPostCode); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Country"); xmlWriter.WriteAttributeString("isoCountryCode", addressBilling.CountryCode); xmlWriter.WriteString(addressBilling.Country); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("InvoicePartner");
                    xmlWriter.WriteStartElement("Contact");
                    xmlWriter.WriteAttributeString("role", "billTo");
                    xmlWriter.WriteStartElement("Name"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US");
                    xmlWriter.WriteString(addressBilling.ContactName); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("PostalAddress");
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addressBilling.AddrLine1); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addressBilling.AddrLine2); xmlWriter.WriteEndElement();
                    //Can only have 3 Street Parameters according to SAP guidelines//
                    //https://help.sap.com/docs/ariba/sap-ariba-applications-2005-q2-2020-release-guide/invoice-to-cxml-data-mapping
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addressBilling.AddrLine3); xmlWriter.WriteEndElement();
                    //Assumed Address 4 & 5 hold City and State data
                    xmlWriter.WriteStartElement("City"); xmlWriter.WriteString(addressBilling.AddrLine4); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("State"); xmlWriter.WriteString(addressBilling.AddrLine5); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("PostalCode"); xmlWriter.WriteString(addressBilling.AddrPostCode); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Country"); xmlWriter.WriteAttributeString("isoCountryCode", addressBilling.CountryCode); xmlWriter.WriteString(addressBilling.Country); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    //SHIPPING INFORMATION - DELIVERY ADDRESS
                    xmlWriter.WriteStartElement("InvoiceDetailShipping");
                    xmlWriter.WriteStartElement("Contact");
                    xmlWriter.WriteAttributeString("role", "shipTo");
                    xmlWriter.WriteAttributeString("addressID", "Not Provided");
                    xmlWriter.WriteStartElement("Name"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US");
                    xmlWriter.WriteString(addreddDelivery.ContactName); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("PostalAddress");
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addreddDelivery.AddrLine1); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addreddDelivery.AddrLine2); xmlWriter.WriteEndElement();
                    //Can only have 3 Street Parameters according to SAP guidelines//
                    //https://help.sap.com/docs/ariba/sap-ariba-applications-2005-q2-2020-release-guide/invoice-to-cxml-data-mapping
                    xmlWriter.WriteStartElement("Street"); xmlWriter.WriteString(addreddDelivery.AddrLine3); xmlWriter.WriteEndElement();
                    //Assumed Address 4 & 5 hold City and State data
                    xmlWriter.WriteStartElement("City"); xmlWriter.WriteString(addreddDelivery.AddrLine4); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("State"); xmlWriter.WriteString(addreddDelivery.AddrLine5); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("PostalCode"); xmlWriter.WriteString(addreddDelivery.AddrPostCode); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Country"); xmlWriter.WriteAttributeString("isoCountryCode", addreddDelivery.CountryCode); xmlWriter.WriteString(addreddDelivery.Country); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("PaymentTerm");
                    xmlWriter.WriteAttributeString("payInNumberofDays", "30");
                    xmlWriter.WriteStartElement("Discount");
                    xmlWriter.WriteStartElement("DiscountPercent"); xmlWriter.WriteAttributeString("percent", "0"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("DiscountDueDays"); xmlWriter.WriteString("0"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("NetDueDays"); xmlWriter.WriteString("30"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteEndElement();//END InvoiceDetailRequestHeader

                    xmlWriter.WriteStartElement("InvoiceDetailOrder");
                    xmlWriter.WriteStartElement("InvoiceDetailOrderInfo");
                    xmlWriter.WriteStartElement("OrderReference");
                    xmlWriter.WriteStartElement("DocumentReference"); xmlWriter.WriteAttributeString("payloadID", "30"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    //ADD EACH LINE ITEM TO THE XML FILE//
                    for (int a = 0; a < lstLineItems.Count; a++)
                    {
                        IncludeInvoiceLineItems(xmlWriter, lstLineItems[a],(a+1));
                    }
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("InvoiceDetailSummary");
                    xmlWriter.WriteStartElement("SubtotalAmount");
                    xmlWriter.WriteStartElement("Money");
                    xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString(invoiceCurrent.GrossAmount);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Tax");
                    xmlWriter.WriteStartElement("Money"); xmlWriter.WriteAttributeString("currency", "GBP"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("Description"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("TaxDetails");
                    xmlWriter.WriteAttributeString("purpose", "tax");
                    xmlWriter.WriteAttributeString("category", "sales");
                    xmlWriter.WriteAttributeString("percentageRate", "0");

                    xmlWriter.WriteStartElement("TaxableAmount");
                    xmlWriter.WriteStartElement("Money"); xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString(invoiceCurrent.VATAmount); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("TaxAmount");
                    xmlWriter.WriteStartElement("Money"); xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString(invoiceCurrent.VATAmount); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteStartElement("TaxLocation"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US");
                    xmlWriter.WriteString("GBP"); xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("ShippingAmount");
                    xmlWriter.WriteStartElement("Money");
                    xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString("0");
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("GrossAmount");
                    xmlWriter.WriteStartElement("Money");
                    xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString(invoiceCurrent.GrossAmount);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("NetAmount");
                    xmlWriter.WriteStartElement("Money");
                    xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString(invoiceCurrent.NetAmount);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();

                    xmlWriter.WriteStartElement("DueAmount");
                    xmlWriter.WriteStartElement("Money");
                    xmlWriter.WriteAttributeString("currency", "GBP");
                    xmlWriter.WriteString(invoiceCurrent.NetAmount);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();


                    xmlWriter.WriteEndElement();//END InvoiceDetailSummary

                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndElement();
                    //End Request
                    xmlWriter.WriteEndElement();
                    xmlWriter.Flush();
                }
            }
            Console.WriteLine("Invoice " + invoiceCurrent.Id + " Successfully Exported to cXML. File Path: " + strFileName);
        }

        public void IncludeInvoiceLineItems(XmlWriter xmlWriter, InvoiceLineItem invoiceLineItem,int LinePosition)
        {
            xmlWriter.WriteStartElement("InvoiceDetailItem");
            xmlWriter.WriteAttributeString("invoiceLineNumber", LinePosition.ToString());
            xmlWriter.WriteAttributeString("quantity", invoiceLineItem.Qty);
            xmlWriter.WriteStartElement("UnitOfMeasure"); xmlWriter.WriteString("EA"); xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("UnitPrice");
            xmlWriter.WriteStartElement("Money"); xmlWriter.WriteAttributeString("currency", "GBP"); xmlWriter.WriteString(invoiceLineItem.LineTotal);
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("InvoiceDetailItemReference");
            xmlWriter.WriteAttributeString("lineNumber", LinePosition.ToString());
            xmlWriter.WriteStartElement("ItemID");
            xmlWriter.WriteStartElement("SupplierPartID"); xmlWriter.WriteString(invoiceLineItem.PartNo); xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("Description"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US");
            xmlWriter.WriteString(invoiceLineItem.Description);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("ManufacturerPartID"); xmlWriter.WriteString(invoiceLineItem.PartNo); xmlWriter.WriteEndElement();
            xmlWriter.WriteStartElement("ManufacturerName"); xmlWriter.WriteAttributeString("lang", "http://www.w3.org/XML/1998/namespace", "en-US");
            xmlWriter.WriteString(invoiceLineItem.Manufacturer);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("SubtotalAmount");
            xmlWriter.WriteStartElement("Money");
            xmlWriter.WriteAttributeString("currency", "GBP");
            xmlWriter.WriteString(invoiceLineItem.LineTotal);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("GrossAmount");
            xmlWriter.WriteStartElement("Money");
            xmlWriter.WriteAttributeString("currency", "GBP");
            xmlWriter.WriteString(invoiceLineItem.LineTotal);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteStartElement("NetAmount");
            xmlWriter.WriteStartElement("Money");
            xmlWriter.WriteAttributeString("currency", "GBP");
            xmlWriter.WriteString(invoiceLineItem.LineTotal);
            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();

            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndElement();
        }

    }
}
