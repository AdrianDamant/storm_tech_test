﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CXmlInvoiceGenerator.Infrastructure.Entities
{
    internal class Address
    {
        public string ContactName { get; set; }
        public string AddrLine1 { get; set; }
        public string AddrLine2 { get; set; }
        public string AddrLine3 { get; set; }
        public string AddrLine4 { get; set; }
        public string AddrLine5 { get; set; }
        public string AddrPostCode { get; set; }
        public string CountryCode { get; set; }
        public string Country { get; set; }
    }
}
