﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CXmlInvoiceGenerator.Infrastructure.Entities
{
    internal class Invoice
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public int SalesOrderId { get; set; }
        public string CurrencyCode { get; set; }
        public string NetAmount { get; set; }
        public string VATAmount { get; set; }
        public string GrossAmount { get; set; }
        public string VATCode { get; set; }
        public string VATPercentage { get; set; }
        public string PaymentTermsDays { get; set; }
    }
}
